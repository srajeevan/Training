﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace UniversityApp.Controllers
{
    public class LoginController : Controller
    {
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(FormCollection form)
        {
            string username = form["txtUsername"].ToString();
            string password = form["txtpassword"].ToString();
            if (username == "sreejith" && password == "1234")
            {
                return RedirectToAction("AfterLogin","AfterLogin");
                //return ("Welcome" + username);
            }
            return Content("");
        }

    }
}