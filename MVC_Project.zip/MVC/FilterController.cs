﻿using FiltersDemo.AuthData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FiltersDemo.Controllers
{
    //Action Filter-Outputcache
    public class FilterController : Controller
    {
        // GET: Filter
        
        [OutputCache(Duration = 10)]
        public String Index()
        {
            return DateTime.Now.ToString("T");

        }
        //Authorization Filter
        [Authorize]
        public ActionResult Details()
        {
            return Content("Authorized User");
        }
        public ActionResult Details1()
        {
            return Content("UnAuthorized User");
        }
        [AuthAttribute]
        public string TestRange(int id)
        {
            if (id > 100)
            {
                return String.Format("The Value of Id is {0} ", id);
            }
            else
            {
                throw new ArgumentOutOfRangeException("id", id, "");
            }
        }

    }
}