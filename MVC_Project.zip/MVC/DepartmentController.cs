﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using IMCSTechTraining.DAL;
using IMCSTechTraining.Model;


namespace UniversityApp.Controllers
{
    public class DepartmentController : Controller
    {
        // GET: Department
        [ActionName("DepartmentDetails")]
        public ActionResult DeptDetails()
        {
            UniversityRepository rep = new UniversityRepository();
            List<Department> Department = rep.GetDepartment();
            return View("DeptDetails", Department);
        }
        //ctionName("find")]
        public ActionResult GetDep(int id)
        {
            //UniversityRepository rep = new UniversityRepository();
            UniversityRepository rep = new UniversityRepository();
            //IMCSStudentEntities im = new IMCSStudentEntities();
            //Department dpt = im.Departments.Single(dept => dept.DepartmentId == id);
            var st = rep.GetDepartment(id);
            
            return View("GetDep",st);
            
        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            UniversityRepository rep = new UniversityRepository();
            var st = rep.GetDepartment(id);
            return View(st);
        }
        [HttpPost]
        public ActionResult Edit(Department Department)
        {
            if (ModelState.IsValid)
            {
                UniversityRepository rep = new UniversityRepository();
                rep.UpdateDepartment(Department);
                return RedirectToAction("DepartmentDetails");
            }
            return View(Department);
        }
        
    }
}